import '../lib/fontawesome.js';
import { Game, WordNotFound } from '../lib/Game.js';
import center from '../lib/center.js';
import calculateLetterPositions from '../lib/letter_positions.js';
import { getElementCenter, lengthAndAngle } from '../lib/line_position.js';

//------------------ Inicio código Fase 1 -----------------
try {
    const game = new Game(3); //se obtiene un nuevo juego
    const wordPositions = game.wordPositions; //array con las posiciones de las palabras y su longitud
    const gridWidth = 10;
    const gridHeight = 10;
    let maxRow = 0;
    let maxColumn = 0;

    for (const { origin, direction, length } of wordPositions) {
        const [x, y] = origin;

        if (direction === 'horizontal') {
            maxRow = Math.max(maxRow, x + length - 1);
            maxColumn = Math.max(maxColumn, y);
        } else if (direction === 'vertical') {
            maxRow = Math.max(maxRow, x);
            maxColumn = Math.max(maxColumn, y + length - 1);
        }
    } //para obtener, sumando las longitudes de las palabras, la máxima fila y columna a la que llegaran las palabras. Necesario para usar los valores en la funcion center().

    let desplazamiento = center(maxRow, maxColumn, gridWidth, gridHeight); //devuelve un array, por ej, [2, 3], que indica las casillas a desplazar en cada dirección.

    const palabrasCentradas = wordPositions.map(({ origin, direction, length }) => {
        const [x, y] = origin;
        return {
            origin: [x + desplazamiento[0], y + desplazamiento[1]], //se suman las casillas a desplazar para centrarlo
            direction,
            length,
        };
    });

    let divPadre = document.getElementById("grid");

    const posicionesOcupadas = {}; //para letras compartidas por varias palabras

    function crearDivs(palabras) {
        palabras.forEach(({ origin, direction, length }) => {
            const [x, y] = origin;

            for (let i = 0; i < length; i++) {
                const posX = (direction === 'horizontal') ? (x + i) : x;
                const posY = (direction === 'vertical') ? (y + i) : y;

                const clave = `${posX},${posY}`;

                if (!posicionesOcupadas[clave]) {
                    const divLetra = document.createElement('div');
                    divLetra.className = 'letter';
                    divLetra.style.gridArea = `${posY + 1} / ${posX + 1}`;
                    //se suma 1 porque el valor de gridArea empieza en 1, no en 0.

                    divPadre.appendChild(divLetra);

                    posicionesOcupadas[clave] = divLetra;
                    //se añade la posicion ocupada para no repetirla.
                }
            }
        })
    }

    crearDivs(palabrasCentradas); //crea el tablero

    const letras = game.letters; //se obtienen las letras de la rueda
    const numLetras = letras.length;

    const posicionesLetras = calculateLetterPositions(numLetras);

    let wheel = document.getElementById("wheel");

    //funcion para crear un div por letra, con la posicion obtenida arribca en posicionesLetras
    function letrasWheel(posiciones) {
        letras.split('').forEach((letra, i) => {
            const { left, top } = posiciones[i]; //se ponen las variables entre {} porque calculateLetterPositions() devuelve un objeto, para desesctructurarlo.
            const divWheel = document.createElement('div');
            divWheel.className = 'wheel-letter';
            divWheel.style = `left: ${left}; top: ${top}`;
            divWheel.textContent = letra;
            wheel.appendChild(divWheel);
        })
    }

    letrasWheel(posicionesLetras); //Se crean las letras de la rueda.

    //-----------------Bloque Código Fase 4-----------------------
    //Usando las posicionesLetras calculadas:
    function mezclarPosiciones(posiciones) {
        for (let i = posiciones.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [posiciones[i], posiciones[j]] = [posiciones[j], posiciones[i]]; // Intercambia las posiciones
            /*j tendrá valor entre 0 e i (posicion de la letra en el array). Luego se intercambia la letra en la posicion i por la que ocupa la posicion j.
            Ejemplo: array = [A, E, R, B]. Si j = 2 e i=3, el resultado será array=[A, E, B, R], y así hasta mover todas las posiciones.
            */
        }
        return posiciones;
        //devuelve [{x, y}, {x, y}, {x, y}]. Cada {x, y} corresponde a una letra.
    }

    function actualizarPosiciones(posiciones) {
        const divsRueda = document.querySelectorAll(".wheel-letter");

        divsRueda.forEach((divsRueda, i) => {
            const { left, top } = posiciones[i];
            divsRueda.style = `left: ${left}; top: ${top}`;
        });
    }

    const botonesAyuda = document.querySelectorAll(".tool");
    const botonMezcla = botonesAyuda[0];


    botonMezcla.addEventListener("click", () => {
        const posicionesMezcladas = mezclarPosiciones([...posicionesLetras]);
        actualizarPosiciones(posicionesMezcladas); //actualiza los atributos left y top del style de los divs de la wheel, con las nuevas posiciones calculadas.
    });

    //-----------------Fin bloque Código Fase 4-----------------------

    //------------------ Fin código Fase 1 -----------------

    //------------------ Inicio código Fase 2 -----------------
    const divLetras = document.querySelectorAll(".wheel-letter");
    let dibujando = false;
    let lineaActual = null;
    let ultimaLetraSeleccionada = null;

    let palabra = []; //variable creada para la fase 3
    let palabraFinal = ""; //variable creada para la fase 3

    function crearLinea(letra, mouseX, mouseY) {
        const linea = document.createElement('div'); //la linea creada es un elemento div
        linea.classList.add("line");
        const { x: letraCentroX, y: letraCentroY } = getElementCenter(letra);
        const origin = [letraCentroX, letraCentroY];
        const end = [mouseX, mouseY];

        //Se añada la posicion en el atributo estilo
        linea.style.left = `${letraCentroX}px`;
        linea.style.top = `${letraCentroY}px`;

        const { length, angle } = lengthAndAngle(origin, end);

        //Para marcar la trayectoria y que vaya dibujando la letra al mover el ratón.
        linea.style.width = `${length}px`;
        linea.style.transform = `rotate(${angle}deg)`;

        document.body.appendChild(linea); //Se añade la línea al documento, en el body.

        return linea;
    }

    function actualizarLinea(letra, linea, mouseX, mouseY) {
        const { x: letraCentroX, y: letraCentroY } = getElementCenter(letra);
        const origin = [letraCentroX, letraCentroY];
        const end = [mouseX, mouseY];

        const { length, angle } = lengthAndAngle(origin, end);

        linea.style.width = `${length}px`;
        linea.style.transform = `rotate(${angle}deg)`;
    }

    function eliminarLineas() {
        const lineas = document.querySelectorAll(".line");
        lineas.forEach(linea => {
            linea.remove();
        });

    }

    function estaSobreLetra(mouseX, mouseY, letra) {
        const letraRect = letra.getBoundingClientRect();
        //esta función devuelve un objeto DOMRect, con las propiedades de las coordenadas y dimensiones del elemento en relación con la VENTANA DEL NAVEGADOR. En este caso, contiene las posiciones de los BORDES del div.

        const left = letraRect.left;
        const top = letraRect.top;
        const right = letraRect.right;
        const bottom = letraRect.bottom;

        /* Left: distancia del borde izquierdo del elemento (div) respecto al borde izquierdo de la ventana.
        Right: distancia del borde derecho del elemento (div) respecto al borde derecho de la ventana.
        Top: distancia del borde superior del elemento (div) respecto al borde superior de la ventana.
        Bottom: distancia del borde inferior del elemento (div) respecto al borde superior de la ventana.
        */

        return (mouseX >= left && mouseX <= right) && (mouseY >= top && mouseY <= bottom); //comprueba que la posicion del ratón esté dentro de las coordenadas ocupadas por el div. Devuelve True si está dentro, False si está fuera.
    }

    function fijarLineaANuevaLetra(linea, desde, hasta) {
        const { x: desdeX, y: desdeY } = getElementCenter(desde);
        const { x: hastaX, y: hastaY } = getElementCenter(hasta);

        const origin = [desdeX, desdeY];
        const end = [hastaX, hastaY];

        const { length, angle } = lengthAndAngle(origin, end);

        linea.style.left = `${desdeX}px`;
        linea.style.top = `${desdeY}px`;
        linea.style.width = `${length}px`;
        linea.style.transform = `rotate(${angle}deg)`;
    }

    for (let letra of divLetras) {
        letra.addEventListener("mousedown", (event) => {
            if (event.button == 0) {
                letra.classList.add("selected");
                dibujando = true;
                ultimaLetraSeleccionada = letra; //para no repetir la letra seleccionada

                lineaActual = crearLinea(letra, event.clientX, event.clientY); //Se crea la linea cuando se aprieta sobre una letra.

                palabra.push(letra.textContent); //codigo Fase 3 para que añada la letra sobre la que se pulsa a un array de letras, al cual luego se añaden las letras por las que se pasa por encima.
            }

        });
    }

    document.addEventListener("mousemove", (event) => { //eventListener cuando el raton se mueve por el documento.
        if (dibujando && lineaActual) { //Debe existir la linea ya.
            actualizarLinea(ultimaLetraSeleccionada, lineaActual, event.clientX, event.clientY);

            divLetras.forEach(letra => {
                if (letra.classList.contains("selected")) {
                    return; //Cuando se pasa por una letra por la que ya se ha pasado, no hace nada más.
                };

                if (estaSobreLetra(event.clientX, event.clientY, letra)) {
                    if (ultimaLetraSeleccionada !== letra) {
                        fijarLineaANuevaLetra(lineaActual, ultimaLetraSeleccionada, letra);
                        letra.classList.add("selected");
                        lineaActual = crearLinea(letra, event.clientX, event.clientY);
                        ultimaLetraSeleccionada = letra; //Se actualiza la letra por la que se acaba de pasar.

                        palabra.push(letra.textContent); //Código Fase 3, para que añada las letras por las que pasa a un array de letras que se convertirá luego en string.
                    }
                }
            });
        }
    });

    //---------Bloque Código Fase 3---------

    function obtenerCoordenadas(posicion, movimiento, direccion) {
        if (direccion === 'vertical') {
            return [posicion[1] + movimiento, posicion[0]];
        } else {
            return [posicion[1], posicion[0] + movimiento];
        }
    }

    function colocarLetraEnPosicion(fila, columna, letra) {
        //Se selecciona el div que corresponde a la letra y se añade la letra dentro.
        let div = document.querySelector(`.letter[style*="grid-area: ${fila + 1} / ${columna + 1};"]`); //+1 porque gridArea empieza en el 1, no en 0.
        if (div) { //se ejecuta solo si ese div existe y se ha seleccionado.
            div.textContent = letra;
        }
    }

    function colocarPalabraEnDireccion(palabraFinal, posicion, direccion) {
        //Va colocando las letras de la palabra. Va seleccionando el div correspondiente, avanzando por el tablero y en las letras de la palabra.
        for (let i = 0; i < palabraFinal.length; i++) {
            let [fila, columna] = obtenerCoordenadas(posicion, i, direccion);
            colocarLetraEnPosicion(fila, columna, palabraFinal.charAt(i));
        }
    }

    function anyadirPalabra(palabraFinal) {

        if (palabraFinal === "") {
            return; //si no se han seleccionado letras, no hace nada.
        }

        let posicionPalabraSeleccionada = game.findWord(palabraFinal);
        //devuelve un objeto con { origin: [x, y], direction: 'vertical'/'horizontal'}.

        //Centrar la palabra, usando la variable desplazamiento obtenida al principio de la función centrar()
        const palabraSeleccionadaCentrada = [
            posicionPalabraSeleccionada.origin[0] + desplazamiento[0],
            posicionPalabraSeleccionada.origin[1] + desplazamiento[1]
        ];

        if (posicionPalabraSeleccionada.direction === 'vertical') {
            colocarPalabraEnDireccion(palabraFinal, palabraSeleccionadaCentrada, 'vertical');
        } else if (posicionPalabraSeleccionada.direction === 'horizontal') {
            colocarPalabraEnDireccion(palabraFinal, palabraSeleccionadaCentrada, 'horizontal');
        }
    }

    document.addEventListener("mouseup", () => { //Al levantar el raton
        if (dibujando) { //Solo se ejecuta cuando se habia creado una linea y se suelta el ratón.
            eliminarLineas();
            dibujando = false;

            divLetras.forEach(letra => {
                letra.classList.remove("selected"); //Se "des-seleccionan" las letras por las que se ha pasado.
            });

            //La palabra se debe añadir, si es válida, al soltar el ratón, por eso este código se coloca dentro de este eventLinstener.

            //Código fase 3
            palabraFinal = palabra.join('');
            palabra = []; //para vaciar el array de letras seleccionadas.

            anyadirPalabra(palabraFinal);

            //------------------ Fin código Fase 3 -----------------
        }
    });
    //------------------ Fin código Fase 2 -----------------

    //---------------- Bloque código Fase 4 -----------------
    //Ayuda Bombilla y Diana

    //Funcion para btener divs vacios. Se añaden en un array.
    function posicionesVacias() {
        const divsTablero = document.querySelectorAll(".letter");
        const divsVacios = [];
        for (let divLetra of divsTablero) {
            if (divLetra.textContent === "") {
                divsVacios.push(divLetra);
            }
        }
        return divsVacios;
    }

    function anyadirLetraRandom(divARevelar) {
        //A partir del atributo grid-area se obtiene la posicion del div seleccionado de manera aleatoria.
        const gridArea = divARevelar.style.gridArea;

        const posicion = gridArea.split(" / "); //Para obtener la posicion en formato [x, y] desde el atributo grid-area.

        //grid-area tiene formato fila/columna, pero letterAt espera (columna, fila).
        const columna = parseInt(posicion[1], 10) - 1; //-1 porque gridArea empieza en 1, pero las letras del juego empiezan en 0.
        const fila = parseInt(posicion[0], 10) - 1; //El 10 es indica a parseInt que lo debe convertir a un numero de base 10.

        const posicionAntesDeCentrar = [columna - desplazamiento[0], fila - desplazamiento[1]]; //se le restan las posiciones desplazadas para centrar las letras.

        const letra = game.letterAt(posicionAntesDeCentrar[0], posicionAntesDeCentrar[1]); //se obtiene la letra de esa posicion.

        divARevelar.textContent = letra; //Se añade la letra al div vacio.

    }

    function ayudaBombilla(divsVacios) {
        if (divsVacios.length === 0) {
            return;
        }
        const indice = Math.floor(Math.random() * divsVacios.length);
        const divSeleccionado = divsVacios[indice]; //Selecciona in div random de todos los que hay vacios todavia, y lo devuelve.

        anyadirLetraRandom(divSeleccionado);

    }

    const botonBombilla = botonesAyuda[2]; //Se selecciona el elemento del boton de ayuda

    botonBombilla.addEventListener("click", () => {
        const divsSinLetra = posicionesVacias(); //Se obtiene el array de divs todavia vacios.
        ayudaBombilla(divsSinLetra);
    });

    //Ayuda diana (hammer)
    const botonDiana = botonesAyuda[1];

    botonDiana.addEventListener("click", () => {
        const divsSinLetra = posicionesVacias();
        
        const cantidadARevelar = Math.min(5, divsSinLetra.length); // Selecciona el minimo entre 5 y el numero de divs vacios. Si hay menos de 5 divs vacios, selecciona los que hay.

        for (let i = 0; i < cantidadARevelar; i++) {
            const indice = Math.floor(Math.random() * divsSinLetra.length);
            const divSeleccionado = divsSinLetra.splice(indice, 1)[0]; //Devuelve un elemento del array, y a la vez lo elimina del array. Así una vez se añada la letra ya no se puede volver a seleccionar para poner la letra.

            if (divSeleccionado) {
                anyadirLetraRandom(divSeleccionado); //Añade la letra al div seleccionado, que ya no estará disponible en la siguiente iteración.
            }
        }
    })

    //---------------------Fin bloque código Fase 4 -----------------------

    //---------- Contenido código Fase 1 (continuación del try) ----------
} catch (error) {
    if (error instanceof WordNotFound) {
        console.error(error.message); //lanza un mensaje por consola: "La palabra xxx no está en el juego ID_juego".
    } else {
        console.error('Error inesperado: ', error);
    }
}


