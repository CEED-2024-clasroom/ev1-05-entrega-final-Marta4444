import '../lib/fontawesome.js';
import { Game, WordNotFound } from '../lib/Game.js';
//import center from '../lib/center.js';
//import calculateLetterPositions from '../lib/letter_positions.js';
//import { getElementCenter, lengthAndAngle } from '../lib/line_position.js';
import { centrarPalabras, crearTablero } from '../JS/crearTablero.js';
import { crearRuedaLetras } from '../JS/crearLetrasRueda.js';
import { mezclarLetras } from '../JS/botonShuffle.js';
import { revelarLetra, revelar5Letras } from '../JS/botonBombilla.js';
import { anyadirPalabra } from '../JS/anyadirPalabra.js';
import { crearLinea, estaSobreLetra, eliminarLineas, actualizarLinea, fijarLineaANuevaLetra } from '../JS/crearLineas.js';
import { ayudaMartillo } from '../JS/botonMartillo.js';


try {
    const game = new Game(3); //se obtiene un nuevo juego
    const wordPositions = game.wordPositions; //array con las posiciones de las palabras y su longitud
    const gridWidth = 10;
    const gridHeight = 10;

    const desplazamiento = centrarPalabras(wordPositions, gridWidth, gridHeight); //Se centran las palabras para crear el tablero.

    crearTablero(wordPositions, desplazamiento); //Se crea el tablero a partir del código del módulo crearTablero.js.

    const letras = game.letters; //se obtienen las letras de la rueda

    const posicionesLetras = crearRuedaLetras(letras); //Se crean las letras de la rueda. Devuelve las posiciones de las letras. Necesario para luego cambiarlas de posicion con el boton de shuffle.

    //Ayuda Mezcla    
    const botonesAyuda = document.querySelectorAll(".tool"); //Seleccionar botones de ayuda, todos.
    const botonMezcla = botonesAyuda[0];
    const funcionMezclarLetras = () => mezclarLetras(posicionesLetras); //Necesario guardar la referencia a la funcion para pasarla al eventListener.
    botonMezcla.addEventListener("click", funcionMezclarLetras);

    //Crear Lineas y colocar palabra
    const divLetras = document.querySelectorAll(".wheel-letter");
    let dibujando = false;
    let lineaActual = null;
    let ultimaLetraSeleccionada = null;
    let palabra = []; //variable creada para la fase 3
    let palabraFinal = ""; //variable creada para la fase 3

    const manejarMouseDown = function mouseDown(event) {
        if (event.button == 0) {
            const letra = event.currentTarget;
            letra.classList.add("selected");
            dibujando = true;
            ultimaLetraSeleccionada = letra; //para no repetir la letra seleccionada

            lineaActual = crearLinea(letra, event.clientX, event.clientY); //Se crea la linea cuando se aprieta sobre una letra.

            palabra.push(letra.textContent); //codigo Fase 3 para que añada la letra sobre la que se pulsa a un array de letras, al cual luego se añaden las letras por las que se pasa por encima.
        }
    }

    const manejarMouseMove = function mouseMove(event) {
        if (dibujando && lineaActual) { //Debe existir la linea ya.
            actualizarLinea(ultimaLetraSeleccionada, lineaActual, event.clientX, event.clientY);

            divLetras.forEach(letra => {
                if (letra.classList.contains("selected")) {
                    return; //Cuando se pasa por una letra por la que ya se ha pasado, no hace nada más.
                };

                if (estaSobreLetra(event.clientX, event.clientY, letra)) {
                    if (ultimaLetraSeleccionada !== letra) {
                        fijarLineaANuevaLetra(lineaActual, ultimaLetraSeleccionada, letra);
                        letra.classList.add("selected");
                        lineaActual = crearLinea(letra, event.clientX, event.clientY);
                        ultimaLetraSeleccionada = letra; //Se actualiza la letra por la que se acaba de pasar.

                        palabra.push(letra.textContent); //Código Fase 3, para que añada las letras por las que pasa a un array de letras que se convertirá luego en string.
                    }
                }
            });
        }
    }

    const manejarMouseUp = function mouseUp() {
        if (dibujando) { //Solo se ejecuta cuando se habia creado una linea y se suelta el ratón.
            eliminarLineas();
            dibujando = false;

            divLetras.forEach(letra => {
                letra.classList.remove("selected"); //Se "des-seleccionan" las letras por las que se ha pasado.
            });

            //La palabra se debe añadir, si es válida, al soltar el ratón, por eso este código se coloca dentro de este eventLinstener.
            palabraFinal = palabra.join('');
            palabra = []; //para vaciar el array de letras seleccionadas.

            anyadirPalabra(palabraFinal, desplazamiento, game);
        }
    }

    //EventListeners para crear lineas y añadir palabras
    for (let letra of divLetras) {
        letra.addEventListener("mousedown", manejarMouseDown);
    }
    document.addEventListener("mousemove", manejarMouseMove);
    document.addEventListener("mouseup", manejarMouseUp);

    //Ayuda Bombilla (revelar 1 letra)
    const botonBombilla = botonesAyuda[2]; //Se selecciona el elemento del boton de ayuda
    const funcionRevelarLetra = () => revelarLetra(desplazamiento, game);
    botonBombilla.addEventListener("click", funcionRevelarLetra);

    //Ayuda diana (revelar 5 letras)
    const botonDiana = botonesAyuda[1];
    const funcionRevelar5Letras = () => revelar5Letras(desplazamiento, game);
    botonDiana.addEventListener("click", funcionRevelar5Letras);

    //---------------------- Codigo Fase 5 ---------------------
    const botonMartillo = botonesAyuda[3];
    const divBlack = document.getElementById("black");
    const letrasTablero = document.querySelectorAll(".letter");

    botonMartillo.addEventListener("click", (event) => {
        event.stopPropagation(); //Para evitar que finalice la ayuda al hacer click sobre el martillo (document.addEventListener con manejarClickExterno)
        ayudaMartillo(divBlack, letrasTablero, desplazamiento, game);
    });

} catch (error) {
    if (error instanceof WordNotFound) {
        console.error(error.message); //lanza un mensaje por consola: "La palabra xxx no está en el juego ID_juego".
    } else {
        console.error('Error inesperado: ', error);
    }
}


