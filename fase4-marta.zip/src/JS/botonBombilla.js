function posicionesVacias() {
    const divsTablero = document.querySelectorAll(".letter");
    const divsVacios = [];
    for (let divLetra of divsTablero) {
        if (divLetra.textContent === "") {
            divsVacios.push(divLetra);
        }
    }
    return divsVacios; //Devuelve todos los divs que hay vacios, en un array
}

function anyadirLetra(divARevelar, desplazamiento, game) {
    //A partir del atributo grid-area se obtiene la posicion del div seleccionado de manera aleatoria.
    const gridArea = divARevelar.style.gridArea;

    const posicion = gridArea.split(" / "); //Para obtener la posicion en formato [x, y] desde el atributo grid-area.

    //grid-area tiene formato fila/columna, pero letterAt espera (columna, fila).
    const columna = parseInt(posicion[1], 10) - 1; //-1 porque gridArea empieza en 1, pero las letras del juego empiezan en 0.
    const fila = parseInt(posicion[0], 10) - 1; //El 10 es indica a parseInt que lo debe convertir a un numero de base 10.

    const posicionAntesDeCentrar = [columna - desplazamiento[0], fila - desplazamiento[1]]; //se le restan las posiciones desplazadas para centrar las letras.

    const letra = game.letterAt(posicionAntesDeCentrar[0], posicionAntesDeCentrar[1]); //se obtiene la letra de esa posicion.

    divARevelar.textContent = letra; //Se añade la letra al div vacio.

}


function ayudaBombilla(divsVacios, desplazamiento, game) {
    if (divsVacios.length === 0) {
        return;
    }
    const indice = Math.floor(Math.random() * divsVacios.length);
    const divSeleccionado = divsVacios[indice]; //Selecciona in div random de todos los que hay vacios todavia, y lo devuelve.

    anyadirLetra(divSeleccionado, desplazamiento, game);

}

function revelarLetra(desplazamiento, game) {
    const divsSinLetra = posicionesVacias(); //Se obtiene el array de divs todavia vacios.
    ayudaBombilla(divsSinLetra, desplazamiento, game);
}

function revelar5Letras(desplazamiento, game) {
    const divsSinLetra = posicionesVacias();

    const cantidadARevelar = Math.min(5, divsSinLetra.length); // Selecciona el minimo entre 5 y el numero de divs vacios. Si hay menos de 5 divs vacios, selecciona los que hay.

    for (let i = 0; i < cantidadARevelar; i++) {
        const indice = Math.floor(Math.random() * divsSinLetra.length);
        const divSeleccionado = divsSinLetra.splice(indice, 1)[0]; //Devuelve un elemento del array, y a la vez lo elimina del array. Así una vez se añada la letra ya no se puede volver a seleccionar para poner la letra.

        if (divSeleccionado) {
            anyadirLetra(divSeleccionado, desplazamiento, game); //Añade la letra al div seleccionado, que ya no estará disponible en la siguiente iteración.
        }
    }
}

export { revelarLetra, revelar5Letras, anyadirLetra }