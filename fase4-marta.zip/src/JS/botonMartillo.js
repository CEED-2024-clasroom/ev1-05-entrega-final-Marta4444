import { anyadirLetra } from "../JS/botonBombilla";

function ayudaMartillo(div, letras, desplazamiento, game) {
    div.classList.remove("hidden");

    for (let letra of letras) {
        console.log(("letra: " + letra.classList));
        letra.classList.add("on-top");
        console.log("letra despues: " + letra.classList);
    }

    function finalizarAyuda(clickLetra) {
        letras.forEach((letra) => {
            letra.classList.remove("on-top");
            letra.removeEventListener("click", clickLetra);
        });

        div.classList.add("hidden");
    }

    const manejarClickLetra = (event) => {
        const letra = event.currentTarget;
        if (letra.textContent === "") {
            anyadirLetra(letra, desplazamiento, game);
            finalizarAyuda();
        }
    }

    for (let letra of letras) {
        letra.addEventListener("click", manejarClickLetra);
    }

    const manejarClickExterno = (event) => {
        if (!event.target.classList.contains("letter")) {
            document.removeEventListener("click", manejarClickExterno);
            finalizarAyuda();
        }
    }

    document.addEventListener("click", manejarClickExterno);
}

export { ayudaMartillo }